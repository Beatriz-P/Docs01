#ifndef _XC01_PINOUT_H_
#define _XC01_PINOUT_H_

#define USE_XC01_R5 1
#define MIKROBUS_PWM 5
#define MIKROBUS_INT 7
#define MIKROBUS_RX 9
#define MIKROBUS_TX 10
#define MIKROBUS_SDA 12
#define MIKROBUS_SCL 13
#define MIKROBUS_AN 4
#define MIKROBUS_RST 15
#define MIKROBUS_CS 6
#define MIKROBUS_SCK 8
#define MIKROBUS_MISO 18
#define MIKROBUS_MOSI 17
#define uSD_CS -1
#define BOARD_LED 16
#define BOARD_BUTTON 0

#endif