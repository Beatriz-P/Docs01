#include <Arduino.h>
#include <Wire.h>
#include <SPI.h>

void setup(){

  // mikroBUS GPIO
  pinMode( MIKROBUS_AN, OUTPUT );
  pinMode( MIKROBUS_RST, OUTPUT );
  pinMode( MIKROBUS_CS, OUTPUT );
  pinMode( MIKROBUS_PWM, OUTPUT );
  pinMode( MIKROBUS_INT, OUTPUT );

  digitalWrite( MIKROBUS_AN, HIGH );
  digitalWrite( MIKROBUS_RST, HIGH );
  digitalWrite( MIKROBUS_CS, HIGH );
  digitalWrite( MIKROBUS_PWM, HIGH );
  digitalWrite( MIKROBUS_INT, HIGH );

  // UART config
  Serial.begin( 115200 ); // USB/UART0
  Serial2.begin( 115200, SERIAL_8N1, MIKROBUS_RX, MIKROBUS_TX ); // mikroBUS
  
  // I2C config
  Wire.setPins( MIKROBUS_SDA, MIKROBUS_SCL ); // mikroBUS
  Wire.begin();

  // SPI config
  SPI.begin( MIKROBUS_SCK, MIKROBUS_MISO, MIKROBUS_MOSI ); // mikroBUS
}

void loop(){

  digitalWrite( MIKROBUS_AN, LOW );
  digitalWrite( MIKROBUS_RST, LOW );
  digitalWrite( MIKROBUS_CS, LOW );
  digitalWrite( MIKROBUS_PWM, LOW );
  digitalWrite( MIKROBUS_INT, LOW );

  delay( 1000 );

  digitalWrite( MIKROBUS_AN, HIGH );
  digitalWrite( MIKROBUS_RST, HIGH );
  digitalWrite( MIKROBUS_CS, HIGH );
  digitalWrite( MIKROBUS_PWM, HIGH );
  digitalWrite( MIKROBUS_INT, HIGH );

  delay( 1000 );

}